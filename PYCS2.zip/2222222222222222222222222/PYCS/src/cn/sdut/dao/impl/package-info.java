/**
 * 
 */
/**
 * @author Administrator
 *
 */
package cn.sdut.dao.impl;