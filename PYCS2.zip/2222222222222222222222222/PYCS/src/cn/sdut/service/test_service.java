package cn.sdut.service;

public class test_service {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
